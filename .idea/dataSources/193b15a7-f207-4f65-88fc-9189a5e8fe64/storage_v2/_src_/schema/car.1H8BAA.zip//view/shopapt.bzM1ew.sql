create view shopapt as
  select
    `ap`.`appointment_id` AS `appointment_id`,
    `s`.`shopuser_id`     AS `shopuser_id`,
    `c`.`brand`           AS `brand`,
    `c`.`model`           AS `model`,
    `cu`.`cus_name`       AS `cus_name`,
    `cu`.`cus_phone`      AS `cus_phone`,
    `ap`.`ap_type`        AS `ap_type`,
    `ap`.`ap_time`        AS `ap_time`,
    `ap`.`ap_state`       AS `ap_state`,
    `ap`.`complete_time`  AS `complete_time`,
    `ap`.`payment`        AS `payment`,
    `ap`.`description`    AS `description`
  from (((`car`.`shopuser` `s`
    join `car`.`customeruser` `cu`) join `car`.`appointment` `ap`) join `car`.`car` `c`)
  where ((`s`.`shopuser_id` = `ap`.`shopuser_id`) and (`ap`.`cususer_id` = `cu`.`cususer_id`) and
         (`ap`.`car_id` = `c`.`car_id`));

