create view cususerapt as
  select
    `ap`.`appointment_id` AS `appointment_id`,
    `cu`.`cususer_id`     AS `cususer_id`,
    `c`.`brand`           AS `brand`,
    `c`.`model`           AS `model`,
    `s`.`shop_name`       AS `shop_name`,
    `s`.`shop_phone`      AS `shop_phone`,
    `s`.`shop_address`    AS `shop_address`,
    `s`.`shop_manager`    AS `shop_manager`,
    `ap`.`ap_type`        AS `ap_type`,
    `ap`.`ap_time`        AS `ap_time`,
    `ap`.`ap_state`       AS `ap_state`,
    `ap`.`complete_time`  AS `complete_time`,
    `ap`.`payment`        AS `payment`,
    `ap`.`description`    AS `description`
  from (((`car`.`appointment` `ap`
    join `car`.`customeruser` `cu`) join `car`.`shopuser` `s`) join `car`.`car` `c`)
  where ((`ap`.`cususer_id` = `cu`.`cususer_id`) and (`ap`.`shopuser_id` = `s`.`shopuser_id`) and
         (`ap`.`car_id` = `c`.`car_id`));

