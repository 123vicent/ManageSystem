create view carinfo as
  select
    `su`.`shopuser_id` AS `shopuser_id`,
    `c`.`brand`        AS `brand`,
    `c`.`model`        AS `model`,
    `c`.`type`         AS `type`,
    `soc`.`stock`      AS `stock`,
    `soc`.`price`      AS `price`,
    `soc`.`pic_url`    AS `pic_url`
  from `car`.`shopuser` `su`
    join `car`.`car` `c`
    join `car`.`shopowncar` `soc`
  where ((`su`.`shopuser_id` = `soc`.`shopuser_id`) and (`soc`.`car_id` = `c`.`car_id`));

