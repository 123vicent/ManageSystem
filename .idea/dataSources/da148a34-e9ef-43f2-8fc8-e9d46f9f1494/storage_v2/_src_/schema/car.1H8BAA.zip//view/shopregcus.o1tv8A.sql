create view shopregcus as
  select
    `s`.`shopuser_id`     AS `shopuser_id`,
    `cu`.`cususer_id`     AS `cususer_id`,
    `cu`.`cus_name`       AS `cus_name`,
    `cu`.`cus_phone`      AS `cus_phone`,
    `c`.`brand`           AS `brand`,
    `c`.`model`           AS `model`,
    `c`.`color`           AS `color`,
    `coc`.`register_time` AS `register_time`
  from `car`.`shopuser` `s`
    join `car`.`customeruser` `cu`
    join `car`.`car` `c`
    join `car`.`cusowncar` `coc`
  where ((`s`.`shopuser_id` = `coc`.`shopuser_id`) and (`cu`.`cususer_id` = `coc`.`cususer_id`) and
         (`c`.`car_id` = `coc`.`car_id`));

