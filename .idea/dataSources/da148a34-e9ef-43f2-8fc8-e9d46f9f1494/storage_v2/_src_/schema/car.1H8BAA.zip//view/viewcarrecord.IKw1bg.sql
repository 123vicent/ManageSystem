create view viewcarrecord as
  select
    `vr`.`shopuser_id` AS `shopuser_id`,
    `c`.`brand`        AS `brand`,
    `c`.`model`        AS `model`,
    `c`.`type`         AS `type`,
    `soc`.`price`      AS `price`,
    `vr`.`cususer_id`  AS `cususer_id`,
    `vr`.`view_time`   AS `view_time`
  from `car`.`viewrecord` `vr`
    join `car`.`car` `c`
    join `car`.`shopowncar` `soc`
  where ((`vr`.`car_id` = `c`.`car_id`) and (`vr`.`shopuser_id` = `soc`.`shopuser_id`) and
         (`vr`.`car_id` = `soc`.`car_id`));

