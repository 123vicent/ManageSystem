create view viewcarrecord as
  select
    `vr`.`shopuser_id` AS `shopuser_id`,
    `c`.`brand`        AS `brand`,
    `c`.`model`        AS `model`,
    `c`.`type`         AS `type`,
    `soc`.`price`      AS `price`,
    `vr`.`cususer_id`  AS `cususer_id`,
    `vr`.`view_time`   AS `view_time`
  from ((`car`.`viewrecord` `vr`
    join `car`.`car` `c`) join `car`.`shopowncar` `soc`)
  where ((`vr`.`car_id` = `c`.`car_id`) and (`soc`.`shopuser_id` = `vr`.`shopuser_id`) and
         (`soc`.`car_id` = `vr`.`car_id`));

