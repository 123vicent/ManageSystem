create view carview as
  select
    `soc`.`shopuser_id` AS `shopuser_id`,
    `s`.`shop_name`     AS `shop_name`,
    `s`.`shop_phone`    AS `shop_phone`,
    `s`.`shop_address`  AS `shop_address`,
    `soc`.`car_id`      AS `car_id`,
    `c`.`brand`         AS `brand`,
    `c`.`model`         AS `model`,
    `c`.`color`         AS `color`,
    `c`.`seats`         AS `seats`,
    `c`.`type`          AS `type`,
    `c`.`power`         AS `power`,
    `soc`.`price`       AS `price`,
    `soc`.`pic_url`     AS `pic_url`,
    `soc`.`description` AS `description`
  from `car`.`shopowncar` `soc`
    join `car`.`shopuser` `s`
    join `car`.`car` `c`
  where ((`soc`.`shopuser_id` = `s`.`shopuser_id`) and (`soc`.`car_id` = `c`.`car_id`));

